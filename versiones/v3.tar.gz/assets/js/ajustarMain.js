// var alturaOriginal = $(".main").height();
// function ajustarMain() {
// 	var tamanoTotal = $("body").height();
// 	var alturaHeader = $(".header").height();
// 	var alturaFooter = $(".footer").height();
// 	var nuevaAltura = tamanoTotal - alturaHeader - alturaFooter - 10;

// 	$(".main").height(nuevaAltura);
// }

// $(window).resize(ajustarMain);