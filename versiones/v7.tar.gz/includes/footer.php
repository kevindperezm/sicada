</div>
</div>
<div class="footer row">
	<div class="small-12 columns text-center">
		<span>SICADA</span><br>
		<span>Desarrollado por Team 1</span>
	</div>
</div>
</div>

<script src="../assets/js/jquery-1.11.0.min.js"></script>
<script src="../assets/js/foundation.min.js"></script>
<script src="../assets/js/ajustarMain.js"></script>
<script>
	$(document).foundation();

	/* Funcionamiento de los filtros */
	$(".filtro-input").keyup(function(e){
		var filas = $(this).parent().parent().find(".filtro-tabla tr:not(.encabezados)");
		var val = $(this).val();
		if (val == "") {
			filas.css({
				display: "auto"
			});
		} else {
			filas.each(function(){
				var colval = $(this).children("td:first").text().toLowerCase();
				if (colval.indexOf(val) == -1) {
					$(this).css("display", "none");
				} else {
					$(this).css("display", "auto");
				}
			});
		}
	});
	
</script>