function ajustarMain() {
	console.log("Ejecución de ajustarMain");
// 	console.log("SICADAMENU = "+$(".sicada-menu").height());
// 	console.log("CONTENIDO = "+$(".sicada-contenido").height());
// 	console.log($(".sicada-menu").height() < $(".sicada-contenido").height());
	if (/*$(".sicada-menu").height() < $("body").height()*/ true) {
		console.log("Menú más pequeño que body");
		if ($(".sicada-menu").height() < $(".sicada-contenido").height()) {
			console.log("Menú más pequeño que .sicada-contenido");
			$(".sicada-menu").height($(".sicada-contenido").height() - 5);
		} else {
			console.log("Menú más grande que .sicada-contenido");
			var tamanoTotal = $("body").height();
			var alturaHeader = $(".header").height();
			var alturaFooter = $(".footer").height();

			var nuevaAlturaMain = tamanoTotal - alturaHeader - alturaFooter - 10;
			$(".sicada-menu").height(nuevaAlturaMain);
		}
	} else {
		console.log("Menú más grande que body");
		$(".sicada-menu").css({
			height: "auto",
			paddingBottom: "3em"
		});
	}
	// console.log($("body").width());
}

$(window).resize(ajustarMain);