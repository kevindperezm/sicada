<?php

class Grupo extends ActiveRecord\Model {
	static $primary_key = "clave_grupo";
	static $belongs_to = array(
		array("carrera", "foreign_key" => "clave_carrera")
	);
	static $has_many = array(
		array("imparticions", "primary_key" => "clave_grupo"),
		array("rangos", "primary_key" => "clave_grupo")
	);
}

?>