<?php

class Carrera extends ActiveRecord\Model {}
	static $primary_key = "clave_carrera";
?>
