 <meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="../assets/css/foundation.min.css">
 <link rel="stylesheet" href="../assets/css/gran-contenedor.css">
 <link rel="stylesheet" href="../assets/css/general.css">
 <link rel="favourite icon" href="../assets/img/nuevo-logo-chico.png">
 <!--[if lt IE 8]>
<link rel="stylesheet" href="css/general-ie.css">
<![endif]-->