<div class="gran-contenedor">
	<div class="header row">
		<div class="small-12 medium-6 large-4 columns text-left sicada-logo">
			<img src="../assets/img/sicada-logo.png" alt="SICADA">
		</div>
		<div class="small-12 medium-6 large-4 columns text-center show-for-medium-up sicada-titulo">
			<h4>Universidad Tecnológica de Manzanillo</h4>
		</div>
		<div class="small-12 medium-6 large-4 columns show-for-large-up text-right sicada-utem">
			<img src="../assets/img/utem-logo.png" alt="UTeM">
		</div>
	</div>