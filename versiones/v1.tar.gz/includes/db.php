<?php

require_once "php-activerecord/ActiveRecord.php";

$cfg = ActiveRecord\Config::instance();
$cfg->set_model_directory('/home/kevin/www/sicada/assets/modelos');
$cfg->set_connections(array('development' => 'mysql://SICADA_admin:SICADA_admin@localhost/SICADA'));

?>