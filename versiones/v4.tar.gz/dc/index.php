<?php 
include '../includes/functions.php'; 
estaLogueado(3);
?>
<!DOCTYPE html>
<html>
<head>
	<title>SICADA</title>
	<?php include "../includes/htmlhead.php"; ?>
</head>
<body>
	<?php include "../includes/header.php"; ?>
	<?php include "../includes/menu.php"; ?>

	<h4>Inicio</h4>

	<?php include "../includes/footer.php"; ?>
</body>
</html>