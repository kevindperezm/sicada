<?php

class Materia extends ActiveRecord\Model {
	static $primary_key = "id_materia";
	static $belongs_to = array(
		array("carrera", "foreign_key" => "id_carrera")
	);
}

?>