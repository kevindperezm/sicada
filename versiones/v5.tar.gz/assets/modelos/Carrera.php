<?php

class Carrera extends ActiveRecord\Model {}
	static $primary_key = "id_carrera";
?>
